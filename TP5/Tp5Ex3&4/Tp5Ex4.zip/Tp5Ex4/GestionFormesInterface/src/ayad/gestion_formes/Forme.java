package ayad.gestion_formes;

public interface Forme {

    double getSurface();
    void affiche();
}
