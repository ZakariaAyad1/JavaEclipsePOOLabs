package zakaria.tp2.exo2;


public class Compte {
	
	String nomTitulaire ;
	
	private int solde = 0 ;
	
	public void deposer(int montant){
		solde = solde + montant ;
	}
	
	public void retirer (int montant){
		
		if (montant <= solde) {
			solde = solde - montant ;
		}else {
			System.out.println("solde insufisant");
		}
		
	}
	
	// Méthode pour virer (transférer) de l'argent d'un compte vers un autre
	public void virerVers(int montant, Compte destination) {
	    // Cette ligne retire la somme spécifiée du compte actuel (l'objet courant)
	    this.retirer(montant);   // 1er compte (compte courant)

	    // Cette ligne dépose la même somme sur le compte destination
	    destination.deposer(montant); // 2ème compte (compte de destination)
	}
	
	public void afficher(){
		System.out.println("solde : " + solde) ; 
		System.out.println("le nom titulaire du compte (de type String) " + nomTitulaire);
		
	}
	
	public Compte(String nomTitulaire) {
		this.nomTitulaire = nomTitulaire;
	}
	
	// Constructeur par défaut
    public Compte() {
        this.nomTitulaire = "Titulaire inconnu";
    }
	
}
