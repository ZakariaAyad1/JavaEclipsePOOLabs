package zakaria.tp2.exo2;

public class TestCompte {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Compte compte1 = new Compte();
		Compte compte2 = new Compte();
		
		compte1.deposer(600);
		compte2.deposer(850);
		
		compte2.retirer(200);
		
		compte1.virerVers(150 , compte2);
		compte2.retirer(1800);
		
		compte1.afficher();
		compte2.afficher();
		
		Compte compte3 = new Compte("zakaria");
		
		

	}

}
