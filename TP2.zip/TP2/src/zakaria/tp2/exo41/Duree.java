package zakaria.tp2.exo41;

public class Duree {
	

	    private double decimalHours;

	    public Duree(int heures, int minutes, int secondes) {
	        this.decimalHours = heures + (minutes / 60.0) + (secondes / 3600.0);
	    }

	    public Duree(double heuresDecimales) {
	        this.decimalHours = heuresDecimales;
	    }

	    public double getDec() {
	        return decimalHours;
	    }

	    public int getH() {
	        return (int) decimalHours;
	    }

	    public int getM() {
	        return (int) ((decimalHours - getH()) * 60);
	    }

	    public int getS() {
	        return (int) (((decimalHours - getH()) * 60 - getM()) * 60);
	    }

	    public static void main(String[] args) {
	        Duree d1 = new Duree(2, 30, 50);
	        System.out.println("Decimal: " + d1.getDec());
	        System.out.println("Heures: " + d1.getH() + ", Minutes: " + d1.getM() + ", Secondes: " + d1.getS());

	        Duree d2 = new Duree(2.514);
	        System.out.println("Decimal: " + d2.getDec());
	        System.out.println("Heures: " + d2.getH() + ", Minutes: " + d2.getM() + ", Secondes: " + d2.getS());
	    }
	


	
}
