package zakaria.tp2.exo41;

public class Duree2 {
    private int heures;
    private int minutes;
    private int secondes;

    public Duree2(int heures, int minutes, int secondes) {
        this.heures = heures;
        this.minutes = minutes;
        this.secondes = secondes;
    }

    public Duree2(double heuresDecimales) {
        this.heures = (int) heuresDecimales;
        this.minutes = (int) ((heuresDecimales - heures) * 60);
        this.secondes = (int) ((((heuresDecimales - heures) * 60) - minutes) * 60);
    }

    public double getDec() {
        return heures + (minutes / 60.0) + (secondes / 3600.0);
    }

    public int getH() {
        return heures;
    }

    public int getM() {
        return minutes;
    }

    public int getS() {
        return secondes;
    }

    public static void main(String[] args) {
        Duree2 d1 = new Duree2(2, 30, 50);
        System.out.println("Decimal: " + d1.getDec());
        System.out.println("Heures: " + d1.getH() + ", Minutes: " + d1.getM() + ", Secondes: " + d1.getS());

        Duree2 d2 = new Duree2(2.514);
        System.out.println("Decimal: " + d2.getDec());
        System.out.println("Heures: " + d2.getH() + ", Minutes: " + d2.getM() + ", Secondes: " + d2.getS());
    }
}
