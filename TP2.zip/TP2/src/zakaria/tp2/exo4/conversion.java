package zakaria.tp2.exo4;

public class conversion {
    private double DH;

	public conversion(int hours, int minutes, int seconds) {
		this.DH = hours + minutes / 60.0 + seconds / 3600.0;	
	}
	public conversion(double d) {
		this.DH=d;
	}
	public double getDec() {
		return DH;
	}
	
	public int getH() {
		return (int) DH;
		
	}
	
	public int getM() {
		return (int) ((DH - getH()) * 60);
		
	}
	
	public int getS() {
		return (int) ((DH - getH())*3600 - getM() * 60);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		conversion d1 = new conversion(2, 30, 30); 
        System.out.println("Decimal: " + d1.getDec());
        System.out.println("Heures: " + d1.getH() + ", Minutes: " + d1.getM() + ", Secondes: " + d1.getS());

        conversion d2 = new conversion(2.5);
        System.out.println("Decimal: " + d2.getDec());
        System.out.println("Heures: " + d2.getH() + ", Minutes: " + d2.getM() + ", Secondes: " + d2.getS());
    }
}
