package zakaria.tp2.exo3;

public class Ratio {
	
	int numera ;
	int denomi ;
	
	
	public Ratio(int numera, int denomi) {
        if (denomi == 0) {
            throw new IllegalArgumentException("Denominator cannot be 0.");
        }
        this.numera = numera;
        this.denomi = denomi;
    }

	
	public Ratio produit(Ratio a) {
		return new Ratio(this.numera * a.numera, this.denomi * a.denomi);
	}
	
	public Ratio addition(Ratio a) {
		int newNumera = this.numera * a.denomi + a.numera * this.denomi;
        int newDenomi = this.denomi * a.denomi;
        return new Ratio(newNumera, newDenomi);
	}
	
	public boolean estEgale(Ratio a) {
		if(this.numera * a.denomi == this.denomi * a.numera) {
			return true;
		}else {
			return false;
		}
		
	}
	
	public boolean estPlusGrand(Ratio a) {
		return this.numera * a.denomi > a.numera * this.denomi;	
	}
	
	public String toString() {
		return this.numera + "/" + this.denomi;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ratio r = new Ratio(2,1);
		Ratio r2=new Ratio(3,1);
		System.out.println(r.produit(r2));
		System.out.println(r.addition(r2));
		System.out.println(r.estEgale(r2));		
		System.out.println(r.estPlusGrand(r2));
		System.out.println(r);
		
		
	
	}

}
