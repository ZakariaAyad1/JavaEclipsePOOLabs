package ma.ensate;

import java.util.Scanner;

public class EX5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true; 

        while (running) {
            System.out.println("Veuillez choisir un des programmes suivants :");
            System.out.println("1-Somme et produit de deux entiers");
            System.out.println("2-Surface d’un carré");
            System.out.println("3-Factorielle d’un nombre");
            System.out.println("4-Dessiner un triangle");
            System.out.println("5-Quitter le programme");

            int n = scanner.nextInt();

            switch (n) {
                case 1:
                    
                    EX1.main(new String[]{}); 
                    break;
                case 2:
                    
                    EX2.main(new String[]{}); 
                    break;
                case 3:
                    
                    EX3.main(new String[]{}); 
                    break;
                case 4:
                    
                    EX4.main(new String[]{}); 
                    break;
                case 5:
                    
                    System.out.println("Au revoir!");
                    running = false;
                    break;
                default:
                    System.out.println("Choix invalide. Veuillez réessayer.");
            }
        }

        //scanner.close(); 
    }
}
