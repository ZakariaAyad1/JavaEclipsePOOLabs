package ma.ensate;
import java.util.Scanner;


public class EX1{
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("premier :");
		int nombre1 = scanner.nextInt();
		
		System.out.print(" deuxième nombre entier:");
		int nombre2 = scanner.nextInt();
		
		int somme = nombre1 +  nombre2;
		int produit = nombre1 * nombre2;
		
		System.out.println("somme :" + somme);
		System.out.println("produit :" + produit);
		
		//scanner.close();
		
	}
}





        
     
