package ma.ensate;
import java.util.Scanner;

public class EX3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("programme en java qui permet de calculer la factorielle d’un nombre saisi au clavier");
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("entrer entier pour calculer la factorielle positive");
		int NmbFac = scanner.nextInt();
		
		if (NmbFac < 0) {
			System.out.println("entrer entier positive pour calculer la factorielle");
			NmbFac = scanner.nextInt();
		}
		
		long ResFac=1;
		
		if (NmbFac == 0)
				ResFac=1;
		else
			for (long i=NmbFac ; i>=1 ; i-- ) {
				ResFac=ResFac*i;
			}
		
		System.out.println("factorielle =" + ResFac);
			
		

	}

}
