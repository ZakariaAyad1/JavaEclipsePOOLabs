package ma.ensate;
import java.util.Scanner;

public class EX2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("un algorithme qui permet de calculer la surface d’un carré");
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println(" longueur:");
		
		float longueur= scanner.nextFloat();
		
		float Surface = longueur * longueur;
		
		System.out.println(" Surface d’un carré = longueur * longueur : " + Surface);
		
	}

}
